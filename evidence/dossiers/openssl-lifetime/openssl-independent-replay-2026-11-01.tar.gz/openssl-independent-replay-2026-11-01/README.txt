OpenSSL independent replay — 1 November 2026

Read VERDICT.txt for the concise outcome and REPORT.txt for scope, caveats,
assumptions, provenance, paper wording and exact reproduction commands.

Offline source verification:
  python3 verify_sources.py

Fresh build and kernel check (requires Rocq/coqc, coqdep and coqchk):
  ROCQ_BIN=/Users/umang/.opam/default/bin python3 replay.py

Change ROCQ_BIN for your machine. No upstream files need editing. The tested
version was Rocq 9.0.0 / OCaml 5.3.0; the official repository checker uses 9.2.0.

The build overwrites logs and regenerates local compiled products. Save the
supplied logs before rerunning if you want to preserve the original replay.
Check delivered file integrity before rerunning:
  shasum -a 256 -c SHA256SUMS
