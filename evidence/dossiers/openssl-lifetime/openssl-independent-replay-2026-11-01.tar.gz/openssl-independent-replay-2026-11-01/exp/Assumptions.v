From Stdlib Require Import List.
From OssFuzzTheorems.Proofs.openssl.bndiv.lib.Spec Require Import BnModel BnTree BnInv BnSpecs BnCorrect.
From Replay Require Import LegacyStaleRef IndependentWitness.
Import ListNotations.

(* Explicitly instantiate the universally quantified legacy client at the
   established upstream initial invariant. *)
Theorem stale_write_from_initial_invariant :
  bwp (bbind (tree_ops nat) (BN_CTX_start (tree_ops nat)) (fun _ =>
       bbind (tree_ops nat) (BN_CTX_get (tree_ops nat)) (fun t =>
       bbind (tree_ops nat) (BN_CTX_end (tree_ops nat)) (fun _ =>
       BN_set_negative (tree_ops nat) t true))))
      ls_init [] (fun _ s X => st_ok s /\ own s X).
Proof.
  destruct (@ls_inv_init nat) as (Hs & Ho & Hr).
  apply LegacyStaleRef.stale_write_accepted; assumption.
Qed.

Print Assumptions BN_CTX_start_spec.
Print Assumptions BN_CTX_get_spec.
Print Assumptions BN_CTX_end_spec.
Print Assumptions BN_set_negative_spec.
Print Assumptions BnCorrect.ls_inv_init.
Print Assumptions BnCorrect.fuzz_one_wp.
Print Assumptions BnCorrect.fuzz_one_rc.
Print Assumptions stale_write_from_initial_invariant.
Print Assumptions IndependentWitness.stale_write_accepted_by_exact_setter_spec.
Print Assumptions IndependentWitness.entire_synthetic_client_executes.
