(* Audit experiment (not part of oss-verify-proofs).
   Against the UNCHANGED bignum Spec files at 98e995d4 (./Spec): the Bg layer's `live` predicate
   (BgInv.v:120) rejects a temporary between BN_CTX_end and the next BN_CTX_get, but is positional:
   after the next start/get the expired reference is `live` again and equals the fresh one. *)
From Stdlib Require Import List Lia.
From OssFuzzTheorems.Proofs.openssl.bignum.lib.Spec Require Import BnModel BnTree BgState BgLib BgInv BgSpecs.
Import ListNotations.

Section Stale.
Context {ptr : Type}.
Local Notation ST := (bstate ptr) (only parsing).
Local Notation ops := (tree_ops ptr) (only parsing).

(* (1) Liveness does end at BN_CTX_end. *)
Lemma bg_dead_after_end : forall F (s : ST),
  (length (gx_frames (st_ctx s)) < BG_DEPTH)%nat -> (gx_used (st_ctx s) < BG_POOL)%nat ->
  hoare F s (bbind ops (BN_CTX_start ops) (fun _ =>
             bbind ops (BN_CTX_get ops) (fun t =>
             bbind ops (BN_CTX_end ops) (fun _ => bret ops t))))
        (fun t s' => ~ live t s').
Proof.
  intros F s Hd Hu.
  eapply hoare_bind; [apply BN_CTX_start_spec; exact Hd|].
  intros [] s1 _ (_ & _ & U1 & Fr1).
  eapply hoare_bind; [apply BN_CTX_get_spec; lia|].
  intros t s2 _ (Et & U2 & Fr2 & _).
  eapply hoare_bind; [apply (BN_CTX_end_spec F s2 (gx_frames (st_ctx s)) (gx_used (st_ctx s))); congruence|].
  intros [] s3 _ (_ & _ & U3 & _).
  apply hoare_ret. unfold live. rewrite Et, U3, U1. unfold RPool. lia.
Qed.

(* (2) ...but the next start/get returns the same index, which is then `live` again, so `live`
       cannot tell the expired reference from the fresh one. *)
Lemma bg_stale_live_again : forall F (s : ST),
  (length (gx_frames (st_ctx s)) < BG_DEPTH)%nat -> (gx_used (st_ctx s) < BG_POOL)%nat ->
  hoare F s (bbind ops (BN_CTX_start ops) (fun _ =>
             bbind ops (BN_CTX_get ops) (fun t =>
             bbind ops (BN_CTX_end ops) (fun _ =>
             bbind ops (BN_CTX_start ops) (fun _ =>
             bbind ops (BN_CTX_get ops) (fun t' => bret ops (t, t')))))))
        (fun tt' s' => fst tt' = snd tt' /\ live (fst tt') s').
Proof.
  intros F s Hd Hu.
  eapply hoare_bind; [apply BN_CTX_start_spec; exact Hd|].
  intros [] s1 _ (_ & _ & U1 & Fr1).
  eapply hoare_bind; [apply BN_CTX_get_spec; lia|].
  intros t s2 _ (Et & U2 & Fr2 & _).
  eapply hoare_bind; [apply (BN_CTX_end_spec F s2 (gx_frames (st_ctx s)) (gx_used (st_ctx s))); congruence|].
  intros [] s3 _ (_ & _ & U3 & Fr3).
  eapply hoare_bind; [apply BN_CTX_start_spec; rewrite Fr3; exact Hd|].
  intros [] s4 _ (_ & _ & U4 & _).
  eapply hoare_bind; [apply BN_CTX_get_spec; lia|].
  intros t' s5 _ (Et' & U5 & _).
  apply hoare_ret. cbn [fst snd]. split.
  - rewrite Et, Et', U4, U3, U1. reflexivity.
  - unfold live. rewrite Et, U5, U4, U3, U1. unfold RPool. lia.
Qed.

End Stale.

Print Assumptions bg_dead_after_end.
Print Assumptions bg_stale_live_again.
