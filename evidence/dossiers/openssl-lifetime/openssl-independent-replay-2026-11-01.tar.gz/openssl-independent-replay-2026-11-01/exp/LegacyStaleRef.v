(* Audit experiment (not part of oss-verify-proofs).
   Checks, against the UNCHANGED bndiv Spec files at commit 98e995d4 (copied to ./Spec), that the
   reusable BN_CTX / valid_ref specifications accept use of a BN_CTX temporary after BN_CTX_end,
   and that the next BN_CTX_get hands out the same reference (aliasing). *)
From Stdlib Require Import ZArith List Lia Bool Permutation.
From OssFuzzTheorems.Proofs.openssl.bndiv.lib.Spec Require Import BnBase BnWords BnKara BnModel BnTree BnInv BnSpecs.
Import ListNotations.
Open Scope Z_scope.

Section Stale.
Context {ptr : Type}.
Local Notation LS := (lstate ptr) (only parsing).
Local Notation ops := (tree_ops ptr) (only parsing).

(* (1) The model's BN_CTX_end keeps cx_vals, so valid_ref of a pool reference survives the end of
       its frame, together with the invariants the other specs need (st_ok, own, ctx_rest). *)
Lemma valid_ref_survives_end : forall (s : LS) X i,
  st_ok s -> own s X -> ctx_wf (ls_ctx s) -> cx_frames (ls_ctx s) = [0%nat] -> valid_ref (RPool i) s ->
  bwp (BN_CTX_end ops) s X
      (fun _ s' X' => st_ok s' /\ own s' X' /\ ctx_rest (ls_ctx s') /\ valid_ref (RPool i) s').
Proof.
  intros s X i Hs Ho Hwf Hfr Hv.
  destruct s as [b1 b2 b3 b4 b5 c].
  destruct c as [hd cur vals pu ps idx fr ss us es tm].
  cbn [ls_ctx cx_frames cx_vals] in *. subst fr.
  destruct Hwf as (Hes & Htm & Hpu & Hus & Hpool & Hstk & _ & _).
  cbn [cx_err_stack cx_too_many cx_pused cx_used cx_psize cx_vals cx_head cx_ssize cx_indexes cx_frames] in *.
  subst es tm pu.
  destruct Hv as [Hi Hne]. cbn [ls_ctx cx_vals] in Hne.
  destruct Hpool as [(_ & E & _ & _)|(Hps & _)]; [contradiction|]. subst ps.
  apply bwp_bind, bwp_getctx. cbn [ls_ctx cx_err_stack cx_frames rev app].
  apply bwp_setctx.
  set (pused := if (0 <? us)%nat then (us - (us - 0))%nat else us).
  assert (Hp0 : pused = 0%nat) by (subst pused; destruct (Nat.ltb_spec 0 us); lia).
  split; [|split; [|split]].
  - apply st_ok_set_ctx; [exact Hs|]. exact (proj2 (proj2 (proj2 (proj2 (proj2 Hs))))).
  - exact Ho.
  - unfold ctx_rest, ctx_wf; cbn [cx_err_stack cx_too_many cx_pused cx_used cx_psize cx_vals cx_head cx_ssize cx_indexes cx_frames ls_ctx set_ctx].
    split; [|reflexivity].
    split; [reflexivity|]. split; [reflexivity|]. split; [exact Hp0|]. split; [lia|].
    split; [right; split; [reflexivity|exact Hne]|].
    split; [destruct Hstk as [(_ & E & _)|E]; [discriminate|right; exact E]|].
    split; [left; reflexivity|]. intros _; reflexivity.
  - split; [exact Hi|]. cbn. exact Hne.
Qed.

(* (2) Their own reusable BN_set_negative_spec then accepts a write through the expired
       temporary: start a frame, get t, end the frame, write through t. *)
Lemma stale_write_accepted : forall (s : LS) X,
  st_ok s -> own s X -> ctx_rest (ls_ctx s) ->
  bwp (bbind ops (BN_CTX_start ops) (fun _ =>
       bbind ops (BN_CTX_get ops) (fun t =>
       bbind ops (BN_CTX_end ops) (fun _ =>
       BN_set_negative ops t true))))
      s X (fun _ s' X' => st_ok s' /\ own s' X').
Proof.
  intros s X Hs Ho Hr.
  apply bwp_bind. apply BN_CTX_start_spec; try assumption.
  intros s1 X1 _ Hs1 Ho1 Hwf1 Hfr1 Hu1.
  apply bwp_bind. apply (BN_CTX_get_spec s1 X1 0%nat); try assumption; [lia|].
  intros s2 X2 Hv2 _ _ Hs2 Ho2 Hwf2 Hfr2 _.
  apply bwp_bind. eapply bwp_mono; [apply (valid_ref_survives_end s2 X2 0%nat); assumption|].
  intros [] s3 X3 (Hs3 & Ho3 & _ & Hv3).
  apply BN_set_negative_spec; try assumption.
  intros Hs4 Ho4. split; assumption.
Qed.

(* (3) Aliasing: after the frame ends, the next start/get returns the SAME reference RPool 0,
       so the expired t and the fresh temporary t' are one and the same bnref. *)
Lemma stale_ref_aliases_next_get : forall (s : LS) X,
  st_ok s -> own s X -> ctx_rest (ls_ctx s) ->
  bwp (bbind ops (BN_CTX_start ops) (fun _ =>
       bbind ops (BN_CTX_get ops) (fun t =>
       bbind ops (BN_CTX_end ops) (fun _ =>
       bbind ops (BN_CTX_start ops) (fun _ =>
       bbind ops (BN_CTX_get ops) (fun t' =>
       bret ops (t, t')))))))
      s X (fun tt' _ _ => fst tt' = RPool 0 /\ snd tt' = RPool 0).
Proof.
  intros s X Hs Ho Hr.
  apply bwp_bind. apply BN_CTX_start_spec; try assumption.
  intros s1 X1 _ Hs1 Ho1 Hwf1 Hfr1 Hu1.
  apply bwp_bind. apply (BN_CTX_get_spec s1 X1 0%nat); try assumption; [lia|].
  intros s2 X2 _ _ _ Hs2 Ho2 Hwf2 Hfr2 _.
  apply bwp_bind. apply BN_CTX_end_spec; try assumption.
  intros s3 _ Hs3 Ho3 Hr3.
  apply bwp_bind. apply BN_CTX_start_spec; try assumption.
  intros s4 X4 _ Hs4 Ho4 Hwf4 Hfr4 Hu4.
  apply bwp_bind. apply (BN_CTX_get_spec s4 X4 0%nat); try assumption; [lia|].
  intros s5 X5 _ _ _ _ _ _ _ _.
  apply bwp_ret. split; reflexivity.
Qed.

End Stale.

Print Assumptions valid_ref_survives_end.
Print Assumptions stale_write_accepted.
Print Assumptions stale_ref_aliases_next_get.
