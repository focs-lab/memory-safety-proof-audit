#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures
ROOT=Path(__file__).resolve().parent
REV='98e995d4daced70a0a4aa2c810854b88720735f1'
raw='https://raw.githubusercontent.com/theorem-labs/oss-verify-proofs/'+REV+'/'
items=[('provenance/commit.json','https://api.github.com/repos/theorem-labs/oss-verify-proofs/git/commits/'+REV)]
for p in ['README.md','LICENSE','NOTICE','projects/openssl/project.yaml','projects/openssl/bndiv/Statements.v','projects/openssl/bndiv/Images.v','projects/openssl/bndiv/dune','projects/openssl/bndiv/images/dune']:
 items.append(('upstream/'+p,raw+p))
sslrev='47aae188a6bdc65675ea9c2a9e770bef48a5d781'
for p in ['doc/man3/BN_CTX_start.pod','crypto/bn/bn_ctx.c']:
 items.append(('openssl/'+p,'https://raw.githubusercontent.com/openssl/openssl/'+sslrev+'/'+p))
def get(item):
 name,url=item; data=urllib.request.urlopen(url,timeout=60).read();p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 return dict(file=name,url=url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: out=list(pool.map(get,items))
(ROOT/'provenance/additional-downloads.json').write_text(json.dumps(out,indent=2)+'\n')
print('Fetched',len(out),'additional provenance files')
