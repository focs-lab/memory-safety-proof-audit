#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, urllib.request, concurrent.futures
ROOT=Path(__file__).resolve().parent
REV='98e995d4daced70a0a4aa2c810854b88720735f1'
metadata=json.loads((ROOT/'provenance/openssl-tree.json').read_text())
select=[]
extras=['bndiv/lib/Theorems.v','bndiv/lib/TopLevel.v','bndiv/lib/TopBndivAsan.v','bndiv/lib/TopBndivPlain.v','bndiv/lib/TopBndivUbsan.v','bndiv/lib/TopE.v','bndiv/lib/dune','bndiv/asan_agrees/Proof.v','bndiv/asan_agrees/dune','bndiv/ubsan_agrees/Proof.v','bndiv/ubsan_agrees/dune','bignum/lib/Spec/BgCtxSpec.v','bignum/lib/Spec/BgFrame.v']
for t in metadata['tree']:
 p=t['path']
 if (p.startswith('bndiv/lib/Spec/Bn') and p.endswith('.v')) or p in extras:
  select.append(t)
def get(t):
 p=t['path']; dest=ROOT/'upstream'/'proofs/openssl'/p
 url=f'https://raw.githubusercontent.com/theorem-labs/oss-verify-proofs/{REV}/proofs/openssl/{p}'
 data=urllib.request.urlopen(url, timeout=60).read()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert actual==t['sha'],(p,actual,t['sha'])
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 return dict(path=str(dest.relative_to(ROOT)),url=url,sha256=hashlib.sha256(data).hexdigest(),git_blob=actual,verified=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 results=list(pool.map(get,select))
(ROOT/'provenance/fresh-downloads.json').write_text(json.dumps(results,indent=2)+'\n')
print('Fetched and verified',len(results),'files')
