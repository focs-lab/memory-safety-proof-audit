#!/usr/bin/env python3
from pathlib import Path
import subprocess, os, json, datetime, time
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
BIN=Path(os.environ.get("ROCQ_BIN", "/Users/umang/.opam/default/bin"))
FLAGS=["-Q", "Spec", "OssFuzzTheorems.Proofs.openssl.bndiv.lib.Spec", "-Q", "exp", "Replay", "-Q", "BgSpec", "OssFuzzTheorems.Proofs.openssl.bignum.lib.Spec"]
LOG=ROOT/"logs"
LOG.mkdir(exist_ok=True)
results=[]
def run(args, name):
    start=time.monotonic()
    with (LOG/(name+".log")).open("w") as f:
        f.write("COMMAND: "+repr(args)+"\n");f.flush()
        cp=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    results.append(dict(command=args,returncode=cp.returncode,elapsed_seconds=round(time.monotonic()-start,3),log=name+".log"))
    (LOG/"build-results.json").write_text(json.dumps(results,indent=2)+"\n")
    print(name,cp.returncode,flush=True)
    if cp.returncode: raise SystemExit(cp.returncode)
run([str(BIN/"coqc"),"--version"],"toolchain")
for directory in ["Spec","BgSpec","exp"]:
    for p in (ROOT/directory).iterdir():
        if p.suffix in [".vo",".vos",".vok",".glob"] or p.name.endswith(".aux"): p.unlink()
files=sorted(str(p.relative_to(ROOT)) for p in (ROOT/"Spec").glob("*.v"))
order=subprocess.check_output([str(BIN/"coqdep"),"-sort",*FLAGS,*files],text=True).split()
(LOG/"dependency-order.txt").write_text("\n".join(order)+"\n")
for f in order: run([str(BIN/"coqc"),*FLAGS,f],Path(f).stem)
bgfiles=sorted(str(p.relative_to(ROOT)) for p in (ROOT/"BgSpec").glob("*.v"))
bgorder=subprocess.check_output([str(BIN/"coqdep"),"-sort",*FLAGS,*bgfiles],text=True).split()
(LOG/"bignum-dependency-order.txt").write_text("\n".join(bgorder)+"\n")
for f in bgorder: run([str(BIN/"coqc"),*FLAGS,f],"Bg-"+Path(f).stem)
for f in ["exp/LegacyStaleRef.v","exp/IndependentWitness.v","exp/BgStale.v","exp/Assumptions.v"]:
    if Path(f).exists(): run([str(BIN/"coqc"),*FLAGS,f],Path(f).stem)

run([str(BIN/"coqchk"),"-silent",*FLAGS,"Replay.IndependentWitness","Replay.LegacyStaleRef","Replay.BgStale","Replay.Assumptions"],"coqchk")
