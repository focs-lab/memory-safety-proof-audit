#!/usr/bin/env python3
"""Offline checks against the retained HTTPS GitHub tree responses."""
from pathlib import Path, PurePosixPath
import hashlib, json
ROOT=Path(__file__).resolve().parent
REV='98e995d4daced70a0a4aa2c810854b88720735f1'
def read(name): return json.loads((ROOT/'provenance'/name).read_text())
def git_hash(kind,data): return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def verify_tree(doc):
    assert not doc['truncated']
    dirs={'':[]}; expected={'':doc['sha']}
    for entry in doc['tree']:
        path=PurePosixPath(entry['path']); parent=str(path.parent)
        if parent=='.':parent=''
        dirs.setdefault(parent,[]).append(entry)
        if entry['type']=='tree': expected[entry['path']]=entry['sha']
    for directory,entries in dirs.items():
        entries.sort(key=lambda e:(PurePosixPath(e['path']).name+('/' if e['type']=='tree' else '')).encode())
        data=b''.join((e['mode'].lstrip('0')+' '+PurePosixPath(e['path']).name).encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
        assert git_hash('tree',data)==expected[directory],directory
commit=read('commit.json');root=read('root-tree.json');proofs=read('proofs-tree.json');ssl=read('openssl-tree.json')
assert commit['sha']==REV and commit['tree']['sha']==root['sha']
assert next(e['sha'] for e in root['tree'] if e['path']=='proofs')==proofs['sha']
assert next(e['sha'] for e in proofs['tree'] if e['path']=='openssl')==ssl['sha']
for doc in [root,proofs,ssl]: verify_tree(doc)
lookup={e['path']:e for e in ssl['tree']}
results=[]
for local,remote in [('Spec','bndiv/lib/Spec'),('BgSpec','bignum/lib/Spec')]:
    for p in sorted((ROOT/local).glob('*.v')):
        data=p.read_bytes();path=remote+'/'+p.name;expected=lookup[path]['sha']
        assert git_hash('blob',data)==expected,path
        results.append({'file':str(p.relative_to(ROOT)),'upstream_path':'proofs/openssl/'+path,'git_blob':expected,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for item in read('fresh-downloads.json'):
    p=ROOT/item['path'];data=p.read_bytes()
    assert hashlib.sha256(data).hexdigest()==item['sha256']
    assert git_hash('blob',data)==item['git_blob']
for item in read('additional-downloads.json'):
    assert hashlib.sha256((ROOT/item['file']).read_bytes()).hexdigest()==item['sha256']
(ROOT/'provenance/verified-build-sources.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: commit-to-tree chain, complete subtree object hashes, and',len(results),'unchanged build sources.')
